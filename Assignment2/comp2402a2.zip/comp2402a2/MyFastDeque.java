package comp2402a2;

/**
 * This class implements the MyDeque interface.
 * @author sharp
 *
 * @param <T> the type of objects stored in the MyDeque
 */
public class MyFastDeque<T> implements MyDeque<T> { 
	
	public MyFastDeque() {
    // TODO: Your code goes here
	}

	public int size() {
    // TODO: Your code goes here
    return -1;
	}
	
	public void addFirst(T x) {
    // TODO: Your code goes here
	}
	
	public void addLast(T x) {
    // TODO: Your code goes here
	}
	
	public T removeFirst() {
    // TODO: Your code goes here
    return null;
	}

	public T removeLast() {
    // TODO: Your code goes here
    return null;
	}
}
