package comp2402a2;

/**
 * This class implements the MyStack interface.
 * @author sharp
 *
 * @param <T> the type of objects stored in the MyStack
 */
public class MyFastStack<T> implements MyStack<T> { 
	
	public MyFastStack() {
    // TODO: Your code goes here
	}

	public int size() {
    // TODO: Your code goes here
    return -1;
	}

	
	public void push(T x) {
    // TODO: Your code goes here
	}
	
	public T pop() {
    // TODO: Your code goes here
    return null;
	}

}
