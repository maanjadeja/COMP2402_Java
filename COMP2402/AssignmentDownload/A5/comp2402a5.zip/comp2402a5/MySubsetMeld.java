package comp2402a5;
/*
 * author: Alexa Sharp
 */

public class MySubsetMeld implements SubsetMeld {

  public MySubsetMeld(int n) {
    throw new UnsupportedOperationException();
  }

  public boolean same(int x, int y) {
    throw new UnsupportedOperationException();
  }

  public void meld(int x, int y) {
    throw new UnsupportedOperationException();
  }

	public int size() {
	    throw new UnsupportedOperationException();
	}

  public int numSubsets() {
	    throw new UnsupportedOperationException();
	}
}
