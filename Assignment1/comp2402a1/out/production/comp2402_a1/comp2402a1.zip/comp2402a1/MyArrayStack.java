package comp2402a1;

import java.util.AbstractList;
import java.util.Collection;

/**
 * This class implements the MyList interface as a single array a.
 * Elements are stored at positions a[0],...,a[size()-1].  
 * Doubling/halving is used to resize the array a when necessary. 
 * @author morin
 * @author sharp
 *
 * @param <T> the type of objects stored in the List
 */
public class MyArrayStack<T> implements MyList<T> { 
	
	/**
	 * The array used to store elements
	 */
	T[] a;
	
	/**
	 * The number of elements stored
	 */
	int n;
	
	/**
	 * Resize the internal array
	 */
	protected void resize() {
		@SuppressWarnings("unchecked")
		T[] b = (T[])new Object[Math.max(n*2, 1)];
		for (int i = 0; i < n; i++) {
			b[i] = a[i];
		}
		a = b;
	}

	/**
	 * Constructor
	 */
	@SuppressWarnings("unchecked")
	public MyArrayStack() {
		a = (T[])new Object[1];
		n = 0;
	}

	/**
	 * Constructor
   *
   * @param cap
	 */
	@SuppressWarnings("unchecked")
	public MyArrayStack(int cap) {
		a = (T[])new Object[cap];
		n = 0;
	}
	
	public int size() { return n; }

	public T get(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		return a[i];
	}
	
	public T set(int i, T x) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T y = a[i];
		a[i] = x;
		return y;
	}
	
	public void add(int i, T x) {
		if (i < 0 || i > n) throw new IndexOutOfBoundsException();
		if (n + 1 > a.length) resize();
		for (int j = n; j > i; j--) 
			a[j] = a[j-1];
		a[i] = x;
		n++;
	}
	
	public T remove(int i) {
		if (i < 0 || i > n - 1) throw new IndexOutOfBoundsException();
		T x = a[i];
		for (int j = i; j < n-1; j++) 
			a[j] = a[j+1];
		n--;
		if (a.length >= 3*n) resize();
		return x;
	}

  public String toString() {
    String s = a.toString();
    String values="";
    // This is the default behaviour of toString.
    // TODO: Override this with more useful behaviour for debugging.

	//iterate through array a and add it to an empty string and return that string

	  for(Object T : a){
	  	values+=T;
	  }
    return values;
  }

  public MyList<T> shuffle(MyList<T> other) {
    // TODO: Return the shuffle of this and other.
	  MyArrayStack<T> stack = new MyArrayStack<T>();

	  //this is a list stored in the class
	  //other is a seperate list

	  //use both list and return a comibnation of both

	  //you have to select the larger size of the

	  int largerSize=0;

	  if(this.size() > other.size()){
	  	largerSize = this.size();
	  }
	  else{
	  	largerSize=other.size();
	  }

	  //while ___!=EMPTY, this.remove(i), other.remove(i)

	  //for(int num: this) {.......}

	  int finalSize = this.size() + other.size();


	  int counter=0;
	  for(int i=0; i<finalSize; i++){
	  	if(this.size() > other.size()){
	  		stack.add(i,this.get(counter));
	  		counter++;
		}
	  	else if(other.size() > this.size()){
			stack.add(i,other.get(counter));
			counter++;
		}
	  	else{
	  		stack.add(i,this.get(counter));
	  		i++;
			stack.add(i,other.get(counter));
			counter++;
		}

	  }


	  //for loop that goes through the larger list, until we hit size of the smallest list, then only
	  //take from larger list
	  //get a size thats a sum of both, then iterate using that value,
	  /*

	  int counter=0;
	  for(int i=0; i<finalSize; i++){
	  	if this stack is > other.size()
	  	then add this.get(counter) to final stack
	  	counter++;


	  	if other stack is >
	  	then just adding other.get(counter)
	  		  counter++;
	  	else{

	  		take this.get(counter)
	  		i++

	  		other.get(counter) and add it to the final stack
	  		counter++;
	  	}


	  }

	  */


	  //MY WORK IS BELOW!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
	  /*int counter=0;
	  for(int i=0; i<largerSize; i++){
	  	if(i>this.size()){
			counter++;
			stack.add(counter,other.get(i));
		}
	  	else if(i>other.size()){
			stack.add(i,this.get(i));
		}
	  	stack.add(i,this.get(i));
	  	counter++;
	  	stack.add(counter,other.get(i));

	  }*/

	  return stack;//this will be the final list you return
    //return this;
  }

	public MyList<MyList<T>> countOff(int n) {
    // TODO: Return a list of n lists, made by counting off
    // the elements in rounds of n.
    MyList<MyList<T>> l = new MyArrayStack<MyList<T>>();
    return l; 
  }

  public void reverse() {
    // TODO: Reverse this MyArrayStack.
  }
}
